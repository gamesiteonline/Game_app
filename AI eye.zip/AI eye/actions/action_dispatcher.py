"""
action_dispatcher.py
--------------------
Maps Gesture enum values to callable Python actions.
Actions are plain functions — easy to extend.
"""

import logging
from typing import Callable, Dict

from gesture_engine import Gesture, GestureEvent

logger = logging.getLogger("ActionDispatcher")


# ======================================================================
# Individual action implementations
# ======================================================================

class Actions:
    """
    Container for all application actions.
    Inject app reference at init so actions can mutate app state.
    """

    def __init__(self, app_ref):
        self.app = app_ref  # Reference to the running KivyApp instance

    # Hand actions
    def execute_action_a(self, event: GestureEvent):
        """Index+Thumb pinch -> Action A (e.g., take screenshot/select)"""
        logger.info("[ACTION A] Pinch Index+Thumb | hand=%s", event.hand)
        self.app.show_notification("Action A: Select", duration=1.5)

    def execute_action_b(self, event: GestureEvent):
        """Middle+Thumb pinch -> Action B (e.g., zoom / confirm)"""
        logger.info("[ACTION B] Pinch Middle+Thumb | hand=%s", event.hand)
        self.app.show_notification("Action B: Confirm", duration=1.5)

    def execute_fist(self, event: GestureEvent):
        """Fist -> Pause / Stop"""
        logger.info("[ACTION] Fist - Pause")
        self.app.show_notification("Paused", duration=1.2)

    def execute_open_palm(self, event: GestureEvent):
        """Open palm -> Resume / Scroll stop"""
        logger.info("[ACTION] Open Palm - Resume")
        self.app.show_notification("Resumed", duration=1.2)

    def execute_peace(self, event: GestureEvent):
        """Peace sign -> Next page"""
        logger.info("[ACTION] Peace - Next Page")
        self.app.show_notification("Next Page", duration=1.0)

    def execute_thumbs_up(self, event: GestureEvent):
        """Thumbs up -> Like / Approve"""
        logger.info("[ACTION] Thumbs Up - Approve")
        self.app.show_notification("Approved!", duration=1.2)

    # Eye actions
    def execute_blink_trigger(self, event: GestureEvent):
        """500ms eye close -> Capture / Toggle UI"""
        logger.info("[ACTION] Blink Trigger - Capture")
        self.app.show_notification("Blink: Captured!", duration=1.5)
        self.app.toggle_camera_mode()

    # Pose actions
    def execute_lean_left(self, event: GestureEvent):
        logger.info("[ACTION] Lean Left - Previous")
        self.app.show_notification("Previous Page", duration=1.0)

    def execute_lean_right(self, event: GestureEvent):
        logger.info("[ACTION] Lean Right - Next")
        self.app.show_notification("Next Page", duration=1.0)


# ======================================================================
# Dispatcher
# ======================================================================

class ActionDispatcher:
    """
    Routes GestureEvents to registered action callables.
    Decouples gesture detection from action implementation.
    """

    def __init__(self, app_ref):
        self._actions = Actions(app_ref)
        self._map: Dict[Gesture, Callable[[GestureEvent], None]] = {
            Gesture.PINCH_INDEX_THUMB: self._actions.execute_action_a,
            Gesture.PINCH_MIDDLE_THUMB: self._actions.execute_action_b,
            Gesture.FIST: self._actions.execute_fist,
            Gesture.OPEN_PALM: self._actions.execute_open_palm,
            Gesture.PEACE: self._actions.execute_peace,
            Gesture.THUMBS_UP: self._actions.execute_thumbs_up,
            Gesture.BLINK_TRIGGER: self._actions.execute_blink_trigger,
            Gesture.LEAN_LEFT: self._actions.execute_lean_left,
            Gesture.LEAN_RIGHT: self._actions.execute_lean_right,
        }

    def dispatch(self, event: GestureEvent):
        handler = self._map.get(event.gesture)
        if handler:
            handler(event)
        else:
            logger.debug("No handler for gesture: %s", event.gesture)

    def register(self, gesture: Gesture, handler: Callable[[GestureEvent], None]):
        """Allow runtime registration of custom gesture handlers."""
        self._map[gesture] = handler
        logger.info("Registered handler for %s", gesture)
