"""
gesture_engine.py
-----------------
MediaPipe Holistic processing engine.

Uses mediapipe.tasks (Lite models) for:
  - Hand landmark detection  -> finger gestures / pinches / fists
  - Face landmark detection  -> eye blink tracking (500ms threshold)
  - Pose landmark detection  -> shoulder lean for directional control

Runs on a dedicated worker thread to avoid blocking the camera/UI threads.
"""

import threading
import time
import logging
from dataclasses import dataclass, field
from typing import Optional, Callable, Dict, List
from enum import Enum, auto

import numpy as np
import mediapipe as mp
from mediapipe.tasks import python as mp_tasks
from mediapipe.tasks.python import vision as mp_vision
from mediapipe.tasks.python.components.containers import landmark as mp_landmark

logger = logging.getLogger("GestureEngine")


# ======================================================================
# Enumerations
# ======================================================================

class Gesture(Enum):
    NONE = auto()
    # Hand gestures
    PINCH_INDEX_THUMB = auto()    # Index + Thumb pinch
    PINCH_MIDDLE_THUMB = auto()   # Middle + Thumb pinch
    FIST = auto()                 # All fingers curled
    OPEN_PALM = auto()            # All fingers extended
    PEACE = auto()                # Index + Middle extended
    THUMBS_UP = auto()            # Thumb up, others curled
    # Eye gestures
    BLINK_TRIGGER = auto()        # Eye closed >= 500ms
    # Pose gestures
    LEAN_LEFT = auto()            # Left shoulder dip
    LEAN_RIGHT = auto()           # Right shoulder dip
    LEAN_FORWARD = auto()         # Both shoulders rise (forward lean)


# ======================================================================
# Data containers
# ======================================================================

@dataclass
class GestureEvent:
    gesture: Gesture
    confidence: float = 1.0
    timestamp: float = field(default_factory=time.monotonic)
    hand: str = "right"          # "left" or "right"
    extra: dict = field(default_factory=dict)


@dataclass
class EngineState:
    """Snapshot of all detected landmarks and active gestures."""
    left_hand_landmarks: Optional[list] = None
    right_hand_landmarks: Optional[list] = None
    face_landmarks: Optional[list] = None
    pose_landmarks: Optional[list] = None
    active_gestures: List[Gesture] = field(default_factory=list)


# ======================================================================
# Landmark index constants (MediaPipe)
# ======================================================================

class HandIdx:
    WRIST = 0
    THUMB_TIP = 4
    INDEX_TIP = 8
    MIDDLE_TIP = 12
    RING_TIP = 16
    PINKY_TIP = 20
    THUMB_MCP = 2
    INDEX_MCP = 5
    MIDDLE_MCP = 9
    RING_MCP = 13
    PINKY_MCP = 17
    INDEX_PIP = 6
    MIDDLE_PIP = 10
    RING_PIP = 14
    PINKY_PIP = 18


class FaceIdx:
    # MediaPipe Face Mesh eye landmarks (simplified)
    LEFT_EYE_TOP = 386
    LEFT_EYE_BOTTOM = 374
    LEFT_EYE_LEFT = 263
    LEFT_EYE_RIGHT = 362
    RIGHT_EYE_TOP = 159
    RIGHT_EYE_BOTTOM = 145
    RIGHT_EYE_LEFT = 133
    RIGHT_EYE_RIGHT = 33


class PoseIdx:
    LEFT_SHOULDER = 11
    RIGHT_SHOULDER = 12
    LEFT_HIP = 23
    RIGHT_HIP = 24
    NOSE = 0


# ======================================================================
# Geometry helpers
# ======================================================================

def _distance(a, b) -> float:
    """Euclidean distance between two landmarks."""
    return ((a.x - b.x) ** 2 + (a.y - b.y) ** 2 + (a.z - b.z) ** 2) ** 0.5


def _ear(eye_top, eye_bottom, eye_left, eye_right) -> float:
    """
    Eye Aspect Ratio (EAR).
    EAR = vertical_distance / horizontal_distance
    Values < 0.2 indicate a closed eye.
    """
    vertical = _distance(eye_top, eye_bottom)
    horizontal = _distance(eye_left, eye_right)
    if horizontal < 1e-6:
        return 0.0
    return vertical / horizontal


# ======================================================================
# Individual gesture detectors
# ======================================================================

class HandGestureDetector:
    """
    Stateless detector — takes a single hand's NormalizedLandmarkList
    and returns a Gesture enum.
    """

    PINCH_THRESHOLD = 0.06    # Normalized distance for pinch
    CURL_THRESHOLD = 0.07     # Tip below MCP for curl detection

    def detect(self, landmarks) -> Gesture:
        lm = landmarks

        # --- Helper closures ---
        def tip(idx):
            return lm[idx]

        def mcp(idx):
            return lm[idx]

        def is_pinching(tip_a, tip_b) -> bool:
            return _distance(tip(tip_a), tip(tip_b)) < self.PINCH_THRESHOLD

        def is_curled(tip_idx, pip_idx) -> bool:
            # Tip is below (higher y) than PIP in image space
            return tip(tip_idx).y > tip(pip_idx).y

        # --- Gesture rules (priority ordered) ---

        # Fist: all four fingers curled
        index_curl = is_curled(HandIdx.INDEX_TIP, HandIdx.INDEX_PIP)
        middle_curl = is_curled(HandIdx.MIDDLE_TIP, HandIdx.MIDDLE_PIP)
        ring_curl = is_curled(HandIdx.RING_TIP, HandIdx.RING_PIP)
        pinky_curl = is_curled(HandIdx.PINKY_TIP, HandIdx.PINKY_PIP)

        if index_curl and middle_curl and ring_curl and pinky_curl:
            return Gesture.FIST

        # Open palm: no fingers curled
        if not index_curl and not middle_curl and not ring_curl and not pinky_curl:
            return Gesture.OPEN_PALM

        # Index+Thumb pinch (Action A)
        if is_pinching(HandIdx.INDEX_TIP, HandIdx.THUMB_TIP):
            return Gesture.PINCH_INDEX_THUMB

        # Middle+Thumb pinch (Action B)
        if is_pinching(HandIdx.MIDDLE_TIP, HandIdx.THUMB_TIP):
            return Gesture.PINCH_MIDDLE_THUMB

        # Peace sign: index + middle extended, rest curled
        if not index_curl and not middle_curl and ring_curl and pinky_curl:
            return Gesture.PEACE

        # Thumbs up: check thumb tip is above wrist, fingers curled
        thumb_up = tip(HandIdx.THUMB_TIP).y < tip(HandIdx.WRIST).y
        if thumb_up and index_curl and middle_curl and ring_curl and pinky_curl:
            return Gesture.THUMBS_UP

        return Gesture.NONE


class EyeBlinkDetector:
    """
    Stateful detector that measures how long both eyes remain closed.
    Fires BLINK_TRIGGER when duration exceeds threshold_ms.
    """

    EAR_CLOSED_THRESHOLD = 0.20

    def __init__(self, threshold_ms: int = 500):
        self.threshold_ms = threshold_ms
        self._closed_since: Optional[float] = None
        self._triggered = False  # Prevent re-firing during same closure

    def update(self, face_landmarks) -> Optional[Gesture]:
        if face_landmarks is None:
            self._reset()
            return None

        lm = face_landmarks

        left_ear = _ear(
            lm[FaceIdx.LEFT_EYE_TOP],
            lm[FaceIdx.LEFT_EYE_BOTTOM],
            lm[FaceIdx.LEFT_EYE_LEFT],
            lm[FaceIdx.LEFT_EYE_RIGHT],
        )
        right_ear = _ear(
            lm[FaceIdx.RIGHT_EYE_TOP],
            lm[FaceIdx.RIGHT_EYE_BOTTOM],
            lm[FaceIdx.RIGHT_EYE_LEFT],
            lm[FaceIdx.RIGHT_EYE_RIGHT],
        )
        avg_ear = (left_ear + right_ear) / 2.0

        if avg_ear < self.EAR_CLOSED_THRESHOLD:
            # Eyes are closed
            if self._closed_since is None:
                self._closed_since = time.monotonic()
                self._triggered = False

            duration_ms = (time.monotonic() - self._closed_since) * 1000
            if duration_ms >= self.threshold_ms and not self._triggered:
                self._triggered = True
                return Gesture.BLINK_TRIGGER
        else:
            self._reset()

        return None

    def _reset(self):
        self._closed_since = None
        self._triggered = False


class PoseGestureDetector:
    """
    Detects body pose gestures from shoulder landmarks.
    Uses a rolling baseline of neutral shoulder height to filter noise.
    """

    LEAN_THRESHOLD = 0.06   # Normalized Y difference for lean detection
    SMOOTHING = 5           # Frames for baseline smoothing

    def __init__(self):
        self._baseline_history: List[float] = []

    def update(self, pose_landmarks) -> Optional[Gesture]:
        if pose_landmarks is None:
            return None

        lm = pose_landmarks
        ls = lm[PoseIdx.LEFT_SHOULDER]
        rs = lm[PoseIdx.RIGHT_SHOULDER]

        # Shoulder Y difference (positive = right shoulder lower)
        shoulder_diff = rs.y - ls.y

        # Update rolling baseline (neutral = shoulders level)
        self._baseline_history.append(shoulder_diff)
        if len(self._baseline_history) > self.SMOOTHING:
            self._baseline_history.pop(0)
        baseline = sum(self._baseline_history) / len(self._baseline_history)

        deviation = shoulder_diff - baseline

        if deviation > self.LEAN_THRESHOLD:
            return Gesture.LEAN_LEFT   # Right shoulder dip = leaning left
        elif deviation < -self.LEAN_THRESHOLD:
            return Gesture.LEAN_RIGHT  # Left shoulder dip = leaning right

        return None


# ======================================================================
# Main engine
# ======================================================================

class GestureEngine:
    """
    Orchestrates all detectors on a worker thread.
    Consumes frames via push_frame() and fires callbacks on gesture detection.
    """

    def __init__(
        self,
        on_gesture: Callable[[GestureEvent], None],
        gesture_cooldown_ms: int = 800,
    ):
        self._on_gesture = on_gesture
        self._cooldown = gesture_cooldown_ms / 1000.0

        # Sub-detectors
        self._hand_detector = HandGestureDetector()
        self._eye_detector = EyeBlinkDetector(threshold_ms=500)
        self._pose_detector = PoseGestureDetector()

        # Threading
        self._frame_lock = threading.Lock()
        self._pending_frame: Optional[np.ndarray] = None
        self._running = False
        self._thread: Optional[threading.Thread] = None

        # Cooldown tracking per gesture
        self._last_fired: Dict[Gesture, float] = {}

        # MediaPipe solution handle
        self._holistic: Optional[mp.solutions.holistic.Holistic] = None

        # Shared state snapshot (read by UI)
        self.state = EngineState()

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def start(self):
        self._holistic = mp.solutions.holistic.Holistic(
            model_complexity=0,        # Lite model for mobile
            enable_segmentation=False,
            refine_face_landmarks=True,
            min_detection_confidence=0.6,
            min_tracking_confidence=0.5,
        )
        self._running = True
        self._thread = threading.Thread(
            target=self._processing_loop,
            name="GestureEngine",
            daemon=True,
        )
        self._thread.start()
        logger.info("GestureEngine started")

    def stop(self):
        self._running = False
        if self._thread:
            self._thread.join(timeout=3.0)
        if self._holistic:
            self._holistic.close()
        logger.info("GestureEngine stopped")

    # ------------------------------------------------------------------
    # Frame ingestion
    # ------------------------------------------------------------------

    def push_frame(self, frame: np.ndarray):
        """Called from the camera thread. Non-blocking."""
        with self._frame_lock:
            self._pending_frame = frame  # Always keep newest frame only

    # ------------------------------------------------------------------
    # Processing loop
    # ------------------------------------------------------------------

    def _processing_loop(self):
        while self._running:
            frame = None
            with self._frame_lock:
                if self._pending_frame is not None:
                    frame = self._pending_frame
                    self._pending_frame = None

            if frame is None:
                time.sleep(0.01)
                continue

            self._process_frame(frame)

    def _process_frame(self, frame: np.ndarray):
        """Run MediaPipe holistic on one frame and emit gesture events."""
        # Convert BGR -> RGB for MediaPipe
        rgb = frame[:, :, ::-1].copy()
        rgb.flags.writeable = False

        results = self._holistic.process(rgb)

        detected: List[Gesture] = []

        # -- Hand gestures --
        for hand_label, hand_lms in [
            ("left", results.left_hand_landmarks),
            ("right", results.right_hand_landmarks),
        ]:
            if hand_lms:
                gesture = self._hand_detector.detect(hand_lms.landmark)
                if gesture != Gesture.NONE and self._can_fire(gesture):
                    event = GestureEvent(
                        gesture=gesture,
                        hand=hand_label,
                        extra={"source": "hand"},
                    )
                    self._fire(event)
                    detected.append(gesture)

        # -- Eye blink --
        face_lms = None
        if results.face_landmarks:
            face_lms = results.face_landmarks.landmark
        blink = self._eye_detector.update(face_lms)
        if blink and self._can_fire(blink):
            self._fire(GestureEvent(gesture=blink, extra={"source": "eye"}))
            detected.append(blink)

        # -- Pose --
        pose_lms = None
        if results.pose_landmarks:
            pose_lms = results.pose_landmarks.landmark
        pose_gesture = self._pose_detector.update(pose_lms)
        if pose_gesture and self._can_fire(pose_gesture):
            self._fire(GestureEvent(gesture=pose_gesture, extra={"source": "pose"}))
            detected.append(pose_gesture)

        # Update shared state
        self.state = EngineState(
            left_hand_landmarks=(
                results.left_hand_landmarks.landmark
                if results.left_hand_landmarks else None
            ),
            right_hand_landmarks=(
                results.right_hand_landmarks.landmark
                if results.right_hand_landmarks else None
            ),
            face_landmarks=face_lms,
            pose_landmarks=pose_lms,
            active_gestures=detected,
        )

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _can_fire(self, gesture: Gesture) -> bool:
        last = self._last_fired.get(gesture, 0)
        return (time.monotonic() - last) >= self._cooldown

    def _fire(self, event: GestureEvent):
        self._last_fired[event.gesture] = time.monotonic()
        try:
            self._on_gesture(event)
        except Exception as exc:
            logger.exception("on_gesture callback raised: %s", exc)
