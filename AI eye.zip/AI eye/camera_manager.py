"""
camera_manager.py
-----------------
Asynchronous dual-camera manager using threading.
Decouples camera I/O from the main Kivy thread to maintain
smooth 30fps UI rendering even during heavy CV processing.
"""

import threading
import time
import logging
from typing import Optional, Callable

import cv2
import numpy as np

logger = logging.getLogger("CameraManager")


class CameraStream:
    """
    A single camera stream running on a dedicated daemon thread.
    Uses a double-buffer strategy: one buffer for writing (capture thread)
    and one for reading (processing thread), swapped atomically.
    """

    def __init__(
        self,
        camera_id: int,
        target_fps: int = 30,
        resolution: tuple = (640, 480),
    ):
        self.camera_id = camera_id
        self.target_fps = target_fps
        self.resolution = resolution

        self._capture: Optional[cv2.VideoCapture] = None
        self._frame_lock = threading.Lock()
        self._latest_frame: Optional[np.ndarray] = None
        self._running = False
        self._thread: Optional[threading.Thread] = None

        # Performance tracking
        self._frame_count = 0
        self._last_fps_time = time.monotonic()
        self.actual_fps: float = 0.0

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def start(self) -> bool:
        """Open camera and start the capture daemon thread."""
        self._capture = cv2.VideoCapture(self.camera_id)
        if not self._capture.isOpened():
            logger.error("Cannot open camera_id=%d", self.camera_id)
            return False

        # Apply resolution hints (may be overridden by driver)
        self._capture.set(cv2.CAP_PROP_FRAME_WIDTH, self.resolution[0])
        self._capture.set(cv2.CAP_PROP_FRAME_HEIGHT, self.resolution[1])
        self._capture.set(cv2.CAP_PROP_FPS, self.target_fps)
        # Reduce internal buffer to minimize latency
        self._capture.set(cv2.CAP_PROP_BUFFERSIZE, 1)

        self._running = True
        self._thread = threading.Thread(
            target=self._capture_loop,
            name=f"CamThread-{self.camera_id}",
            daemon=True,
        )
        self._thread.start()
        logger.info("CameraStream %d started", self.camera_id)
        return True

    def stop(self):
        """Signal thread to stop and release camera resource."""
        self._running = False
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=2.0)
        if self._capture:
            self._capture.release()
            self._capture = None
        logger.info("CameraStream %d stopped", self.camera_id)

    # ------------------------------------------------------------------
    # Internal capture loop
    # ------------------------------------------------------------------

    def _capture_loop(self):
        interval = 1.0 / self.target_fps
        while self._running:
            t0 = time.monotonic()

            ret, frame = self._capture.read()
            if not ret:
                logger.warning("Camera %d: failed to read frame", self.camera_id)
                time.sleep(0.05)
                continue

            # Front camera: mirror horizontally for natural feel
            if self.camera_id == 1:
                frame = cv2.flip(frame, 1)

            with self._frame_lock:
                self._latest_frame = frame

            # FPS calculation (rolling 30-frame window)
            self._frame_count += 1
            if self._frame_count % 30 == 0:
                now = time.monotonic()
                self.actual_fps = 30.0 / (now - self._last_fps_time)
                self._last_fps_time = now

            # Sleep to match target FPS
            elapsed = time.monotonic() - t0
            sleep_time = interval - elapsed
            if sleep_time > 0:
                time.sleep(sleep_time)

    # ------------------------------------------------------------------
    # Public read interface
    # ------------------------------------------------------------------

    def get_frame(self) -> Optional[np.ndarray]:
        """Thread-safe frame access. Returns None if no frame available."""
        with self._frame_lock:
            if self._latest_frame is not None:
                return self._latest_frame.copy()
        return None


# ----------------------------------------------------------------------


class DualCameraManager:
    """
    Manages front (camera_id=1) and back (camera_id=0) cameras.
    Provides a unified interface for toggling active camera and
    optionally compositing a split-screen view.
    """

    MODE_BACK = "back"
    MODE_FRONT = "front"
    MODE_SPLIT = "split"

    def __init__(self, target_fps: int = 30):
        self._back = CameraStream(camera_id=0, target_fps=target_fps)
        self._front = CameraStream(camera_id=1, target_fps=target_fps)
        self._active_mode = self.MODE_FRONT
        self._started = False

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def start(self, mode: str = MODE_FRONT):
        """Start appropriate camera streams based on initial mode."""
        self._active_mode = mode
        if mode in (self.MODE_FRONT, self.MODE_SPLIT):
            self._front.start()
        if mode in (self.MODE_BACK, self.MODE_SPLIT):
            self._back.start()
        self._started = True

    def stop(self):
        self._back.stop()
        self._front.stop()
        self._started = False

    # ------------------------------------------------------------------
    # Mode control
    # ------------------------------------------------------------------

    def toggle_camera(self):
        """Cycle: front -> back -> front"""
        if self._active_mode == self.MODE_FRONT:
            self.set_mode(self.MODE_BACK)
        else:
            self.set_mode(self.MODE_FRONT)

    def set_mode(self, mode: str):
        if mode == self._active_mode:
            return

        # Lazy start / stop streams as needed
        if mode == self.MODE_FRONT:
            self._front.start() if not self._front._running else None
            if self._back._running:
                self._back.stop()
        elif mode == self.MODE_BACK:
            self._back.start() if not self._back._running else None
            if self._front._running:
                self._front.stop()
        elif mode == self.MODE_SPLIT:
            if not self._front._running:
                self._front.start()
            if not self._back._running:
                self._back.start()

        self._active_mode = mode
        logger.info("Camera mode -> %s", mode)

    # ------------------------------------------------------------------
    # Frame access
    # ------------------------------------------------------------------

    def get_active_frame(self) -> Optional[np.ndarray]:
        """
        Returns the primary processing frame (used for MediaPipe).
        In SPLIT mode, returns the front camera frame for gesture detection.
        """
        if self._active_mode == self.MODE_BACK:
            return self._back.get_frame()
        return self._front.get_frame()

    def get_split_frame(self, width: int = 640, height: int = 480) -> Optional[np.ndarray]:
        """
        Composites front + back side-by-side for split-screen display.
        Returns None if either camera is unavailable.
        """
        front = self._front.get_frame()
        back = self._back.get_frame()
        if front is None or back is None:
            return front or back

        half_w = width // 2
        front_r = cv2.resize(front, (half_w, height))
        back_r = cv2.resize(back, (half_w, height))
        return np.hstack([front_r, back_r])

    @property
    def active_mode(self) -> str:
        return self._active_mode

    @property
    def fps_info(self) -> dict:
        return {
            "front": round(self._front.actual_fps, 1),
            "back": round(self._back.actual_fps, 1),
        }
