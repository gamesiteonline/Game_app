"""
overlay.py
----------
Transparent gesture feedback overlay widget for KivyMD.

Features:
 - Animated text pop-up labels
 - Semi-transparent backdrop
 - Dismisses automatically after duration
 - Stacks multiple notifications
"""

import threading
from kivy.clock import Clock
from kivy.graphics import Color, RoundedRectangle
from kivy.uix.label import Label
from kivy.uix.floatlayout import FloatLayout
from kivy.animation import Animation
from kivy.core.window import Window
from kivy.metrics import dp


class GestureNotification(Label):
    """
    A single floating notification pill that fades in/out.
    """

    def __init__(self, text: str, duration: float = 1.5, y_offset: float = 0.15, **kwargs):
        super().__init__(
            text=text,
            font_size=dp(18),
            bold=True,
            color=(1, 1, 1, 0),   # Start transparent
            size_hint=(None, None),
            halign="center",
            **kwargs,
        )
        self._duration = duration
        self._y_offset = y_offset

        # Background pill
        with self.canvas.before:
            self._bg_color = Color(0.1, 0.1, 0.1, 0)
            self._bg_rect = RoundedRectangle(radius=[dp(24)])

        self.bind(size=self._update_bg, pos=self._update_bg)

    def _update_bg(self, *args):
        self._bg_rect.pos = (self.x - dp(16), self.y - dp(8))
        self._bg_rect.size = (self.width + dp(32), self.height + dp(16))

    def animate(self, on_complete: callable):
        """Run fade-in -> hold -> fade-out sequence."""
        # Phase 1: Fade in
        anim_in = Animation(
            color=(1, 1, 1, 1),
            duration=0.2,
        )
        # Phase 2: Hold (implemented via delay in Phase 3)
        anim_out = Animation(
            color=(1, 1, 1, 0),
            duration=0.35,
            t="out_cubic",
        )

        def _start_fade_out(anim, widget):
            Clock.schedule_once(
                lambda dt: anim_out.start(widget),
                self._duration - 0.2 - 0.35,
            )
            anim_out.bind(on_complete=lambda a, w: on_complete(w))

        # Also animate background alpha
        anim_bg_in = Animation(a=0.82, duration=0.2)
        anim_bg_out = Animation(a=0, duration=0.35)

        def _do_bg_fade_out(*_):
            Clock.schedule_once(
                lambda dt: anim_bg_out.start(self._bg_color),
                self._duration - 0.2 - 0.35,
            )

        anim_in.bind(on_complete=_start_fade_out)
        anim_in.bind(on_complete=_do_bg_fade_out)
        anim_in.start(self)
        anim_bg_in.start(self._bg_color)


class GestureOverlay(FloatLayout):
    """
    Fullscreen transparent overlay that manages notification stack.
    Place this on top of the camera preview in z-order.
    """

    VERTICAL_SLOTS = 4      # Max simultaneous notifications
    SLOT_SPACING_DP = 72    # Vertical separation between slots

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._active_slots: list = [None] * self.VERTICAL_SLOTS
        self._lock = threading.Lock()

    def show(self, text: str, duration: float = 1.5):
        """
        Thread-safe. Schedules notification display on main thread.
        """
        Clock.schedule_once(lambda dt: self._create_notification(text, duration))

    def _create_notification(self, text: str, duration: float):
        """Must be called on the main Kivy thread."""
        slot = self._find_free_slot()
        if slot is None:
            return  # All slots occupied; drop notification

        self._active_slots[slot] = True

        # Position: bottom of screen, stacked upward per slot
        base_y = dp(80) + slot * dp(self.SLOT_SPACING_DP)

        notif = GestureNotification(text=text, duration=duration)
        notif.texture_update()
        notif.size = (notif.texture_size[0] or dp(200), dp(40))
        notif.pos = (
            (Window.width - notif.width) / 2,
            base_y,
        )

        self.add_widget(notif)

        def _on_complete(widget):
            self.remove_widget(widget)
            with self._lock:
                self._active_slots[slot] = None

        notif.animate(on_complete=_on_complete)

    def _find_free_slot(self) -> int | None:
        with self._lock:
            for i, slot in enumerate(self._active_slots):
                if slot is None:
                    self._active_slots[i] = True
                    return i
        return None
