"""
main.py
-------
Entry point for the AI Eye Kivy application.
Wires together: DualCameraManager, GestureEngine, ActionDispatcher,
GestureOverlay, and HapticFeedback into a cohesive application.
"""

import logging
import threading
import time
from typing import Optional

import numpy as np
import cv2

from kivy.app import App
from kivy.clock import Clock
from kivy.graphics.texture import Texture
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.image import Image
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.lang import Builder
from kivy.metrics import dp

from kivymd.app import MDApp
from kivymd.uix.dialog import MDDialog
from kivymd.uix.button import MDFlatButton, MDRaisedButton

# Local imports
from camera_manager import DualCameraManager
from gesture_engine import GestureEngine, GestureEvent, Gesture
from actions.action_dispatcher import ActionDispatcher
from ui.overlay import GestureOverlay
from utils.haptics import HapticFeedback
from utils.fps_counter import FPSCounter

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
)
logger = logging.getLogger("AIEyeApp")

# Load KV layout
Builder.load_file("ui/main_screen.kv")


# ======================================================================
# Custom widgets
# ======================================================================

class CameraPreview(Image):
    """
    Image widget that displays live camera frames as a Kivy texture.
    Updated at ~30fps by the Kivy clock.
    """

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.allow_stretch = True
        self.keep_ratio = True
        self._latest_frame: Optional[np.ndarray] = None
        self._frame_lock = threading.Lock()

    def push_frame(self, frame: np.ndarray):
        """Thread-safe frame push from camera thread."""
        with self._frame_lock:
            self._latest_frame = frame

    def update_texture(self, dt):
        """Called from Kivy clock on main thread."""
        with self._frame_lock:
            frame = self._latest_frame
        if frame is None:
            return

        # Convert BGR -> RGB
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        # Flip vertically for Kivy's bottom-origin coordinate system
        flipped = np.flipud(rgb)

        texture = Texture.create(
            size=(flipped.shape[1], flipped.shape[0]),
            colorfmt="rgb",
        )
        texture.blit_buffer(
            flipped.tobytes(),
            colorfmt="rgb",
            bufferfmt="ubyte",
        )
        self.texture = texture


class MainScreen(Screen):
    pass


# ======================================================================
# Application
# ======================================================================

class AIEyeApp(MDApp):
    """
    Root KivyMD Application class.
    Manages all subsystem lifecycles and UI interactions.
    """

    # ------------------------------------------------------------------
    # App lifecycle
    # ------------------------------------------------------------------

    def build(self):
        # Theme
        self.theme_cls.theme_style = "Dark"
        self.theme_cls.primary_palette = "Cyan"
        self.theme_cls.accent_palette = "LightGreen"

        # Screen manager
        self.sm = ScreenManager()
        self.main_screen = MainScreen(name="main")
        self.sm.add_widget(self.main_screen)

        # Subsystems (initialized in on_start to avoid blocking build())
        self._camera: Optional[DualCameraManager] = None
        self._engine: Optional[GestureEngine] = None
        self._dispatcher: Optional[ActionDispatcher] = None
        self._haptics = HapticFeedback()
        self._fps = FPSCounter()

        # State
        self._recording = False
        self._settings_dialog: Optional[MDDialog] = None

        return self.sm

    def on_start(self):
        # Initialize subsystems after the window is ready
        self._init_camera()
        self._init_gesture_engine()
        self._dispatcher = ActionDispatcher(app_ref=self)

        # Start frame feed clock (~30fps display refresh)
        Clock.schedule_interval(self._update_ui, 1.0 / 30.0)
        logger.info("AIEye application started")

    def on_stop(self):
        logger.info("Shutting down...")
        Clock.unschedule(self._update_ui)
        if self._engine:
            self._engine.stop()
        if self._camera:
            self._camera.stop()

    def on_pause(self):
        """Android lifecycle: app goes to background."""
        if self._engine:
            self._engine.stop()
        if self._camera:
            self._camera.stop()
        return True

    def on_resume(self):
        """Android lifecycle: app returns to foreground."""
        self._init_camera()
        self._init_gesture_engine()

    # ------------------------------------------------------------------
    # Initialization helpers
    # ------------------------------------------------------------------

    def _init_camera(self):
        self._camera = DualCameraManager(target_fps=30)
        self._camera.start(mode=DualCameraManager.MODE_FRONT)
        logger.info("Camera manager initialized")

    def _init_gesture_engine(self):
        self._engine = GestureEngine(
            on_gesture=self._on_gesture_detected,
            gesture_cooldown_ms=700,
        )
        self._engine.start()
        logger.info("Gesture engine initialized")

    # ------------------------------------------------------------------
    # UI update loop (Kivy clock)
    # ------------------------------------------------------------------

    def _update_ui(self, dt):
        if self._camera is None:
            return

        # Fetch latest frame
        frame = self._camera.get_active_frame()
        if frame is None:
            return

        # Push to gesture engine (non-blocking)
        if self._engine:
            self._engine.push_frame(frame)

        # Push to display widget
        preview: CameraPreview = self.main_screen.ids.camera_preview
        preview.push_frame(frame)
        preview.update_texture(dt)

        # FPS counter
        self._fps.tick()
        self.main_screen.ids.fps_label.text = f"FPS: {self._fps.fps:.0f}"

        # Camera mode label
        mode_map = {
            DualCameraManager.MODE_FRONT: "FRONT CAM",
            DualCameraManager.MODE_BACK: "BACK CAM",
            DualCameraManager.MODE_SPLIT: "SPLIT VIEW",
        }
        self.main_screen.ids.mode_label.text = mode_map.get(
            self._camera.active_mode, "UNKNOWN"
        )

        # Active gesture label
        state = self._engine.state if self._engine else None
        if state and state.active_gestures:
            gesture_names = ", ".join(g.name for g in state.active_gestures)
            self.main_screen.ids.gesture_label.text = gesture_names
        else:
            self.main_screen.ids.gesture_label.text = "Ready"

    # ------------------------------------------------------------------
    # Gesture callback (from GestureEngine worker thread)
    # ------------------------------------------------------------------

    def _on_gesture_detected(self, event: GestureEvent):
        """
        Called on the GestureEngine worker thread.
        Must dispatch UI calls back to the main thread via Clock.schedule_once.
        """
        logger.info("Gesture: %s (hand=%s)", event.gesture.name, event.hand)

        # Haptic feedback
        self._haptics.buzz()

        # Dispatch action (on worker thread is OK for logic)
        if self._dispatcher:
            self._dispatcher.dispatch(event)

    # ------------------------------------------------------------------
    # Public API (used by ActionDispatcher + UI buttons)
    # ------------------------------------------------------------------

    def show_notification(self, text: str, duration: float = 1.5):
        """Thread-safe: shows an animated overlay notification."""
        overlay: GestureOverlay = self.main_screen.ids.gesture_overlay
        overlay.show(text, duration=duration)

    def toggle_camera_mode(self):
        """Cycles camera: front <-> back."""
        if self._camera:
            self._camera.toggle_camera()
            mode = self._camera.active_mode
            label_map = {
                DualCameraManager.MODE_FRONT: "Front Camera",
                DualCameraManager.MODE_BACK: "Back Camera",
            }
            self.show_notification(label_map.get(mode, "Camera"), duration=1.0)

    def toggle_recording(self, *args):
        """Stub for recording feature (extend as needed)."""
        self._recording = not self._recording
        text = "Recording Started" if self._recording else "Recording Stopped"
        self.show_notification(text)
        btn = self.main_screen.ids.record_btn
        if self._recording:
            btn.md_bg_color = (1, 0.1, 0.1, 1)
        else:
            btn.md_bg_color = (0.8, 0.15, 0.15, 1)

    def open_settings_dialog(self, *args):
        """Simple settings dialog for gesture sensitivity."""
        if self._settings_dialog:
            self._settings_dialog.open()
            return

        self._settings_dialog = MDDialog(
            title="AI Eye Settings",
            text=(
                "Gesture engine running with MediaPipe Lite models.\n"
                "Pinch: Index+Thumb = Action A\n"
                "Pinch: Middle+Thumb = Action B\n"
                "Fist = Pause  |  Palm = Resume\n"
                "Blink 500ms = Capture\n"
                "Lean Left/Right = Navigate"
            ),
            buttons=[
                MDFlatButton(
                    text="CLOSE",
                    on_release=lambda x: self._settings_dialog.dismiss(),
                ),
            ],
        )
        self._settings_dialog.open()


# ======================================================================
# Entry point
# ======================================================================

if __name__ == "__main__":
    AIEyeApp().run()
