# AI Eye - Gesture Control Application

## Overview
AI Eye is a Kivy-based mobile application that uses dual cameras for gesture-based control through AI. It features hands-free navigation and interaction by employing MediaPipe technology for detecting hand gestures, eye movements, and body poses.

## Core Features
- **Dual Camera Management**: Toggle or split-screen mode.
- **Gesture Recognition**: Detects specific hand gestures and invokes associated actions.
- **Eye Tracking**: Recognizes eye blinks to trigger commands.
- **Body Pose Detection**: Detects shoulder movements for directional controls.
- **Optimized for Mobile**: Uses lightweight models to maintain performance.

## Deployment Instructions
For deploying the application on PythonAnywhere, follow the step-by-step guide provided.

## Author
Fahad Groyne
- [Snapchat](https://www.snapchat.com/add/gamesiteonline?share_id=hP7PKuqfIN8&locale=en-GB)
- [Linktree](https://linktr.ee/fahadgroyne)
- [Instagram](https://www.instagram.com/games_site_online?igsh=cnBpc25tNXZtYW52)
- [YouTube](https://www.youtube.com/@gamesiteonline)
- [Threads](https://www.threads.com/@d.e.m.o.x_11)

## Social Links
- [WhatsApp Channel](https://whatsapp.com/channel/0029Vb7jjtZLo4hnTZRnqW1n)
- [TikTok](https://www.tiktok.com/@d.e.m.o.x_11)
- [Pinterest](https://pin.it/5aB39I8wy)

## License
This project is licensed under the terms of the MIT License.
