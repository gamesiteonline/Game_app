[app]
title = AI Eye
package.name = aieye
package.domain = org.aieye
source.dir = .
source.include_exts = py,kv,png,jpg,ttf,spec,tflite

version = 1.0.0
requirements = python3,kivy==2.3.0,kivymd==1.2.0,mediapipe==0.10.14,numpy,opencv-python-headless,plyer

orientation = portrait
fullscreen = 1

android.permissions = CAMERA, VIBRATE, RECORD_AUDIO
android.api = 33
android.minapi = 26
android.ndk = 25b
android.archs = arm64-v8a, armeabi-v7a

android.allow_backup = False
android.logcat_filters = *:S python:D

# Use hardware acceleration for camera
android.manifest.intent_filters =

[buildozer]
log_level = 2
warn_on_root = 1
