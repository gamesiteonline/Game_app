"""
fps_counter.py
--------------
Lightweight rolling FPS counter for UI display.
"""

import time
from collections import deque


class FPSCounter:
    def __init__(self, window: int = 30):
        self._timestamps: deque = deque(maxlen=window)

    def tick(self):
        self._timestamps.append(time.monotonic())

    @property
    def fps(self) -> float:
        if len(self._timestamps) < 2:
            return 0.0
        span = self._timestamps[-1] - self._timestamps[0]
        if span <= 0:
            return 0.0
        return (len(self._timestamps) - 1) / span
