"""
haptics.py
----------
Cross-platform haptic feedback.
Uses Android's Vibrator service via Plyer on mobile;
gracefully degrades to a no-op on desktop.
"""

import logging
import threading

logger = logging.getLogger("Haptics")

try:
    from android.permissions import request_permissions, Permission  # type: ignore
    from jnius import autoclass  # type: ignore

    _PythonActivity = autoclass("org.kivy.android.PythonActivity")
    _Context = autoclass("android.content.Context")
    _VIBRATOR_SERVICE = _Context.VIBRATOR_SERVICE
    ANDROID = True
except ImportError:
    ANDROID = False
    logger.info("Running on non-Android platform. Haptics disabled.")


class HapticFeedback:
    """
    Provides short vibration pulses as gesture confirmation.
    Pattern: [delay_ms, vibrate_ms, pause_ms, vibrate_ms, ...]
    """

    PATTERN_SHORT = [0, 50]              # Single short buzz
    PATTERN_DOUBLE = [0, 50, 100, 50]   # Double tap
    PATTERN_LONG = [0, 200]             # Long confirmation

    def __init__(self):
        self._vibrator = None
        if ANDROID:
            try:
                activity = _PythonActivity.mActivity
                self._vibrator = activity.getSystemService(_VIBRATOR_SERVICE)
            except Exception as exc:
                logger.warning("Could not initialize vibrator: %s", exc)

    def buzz(self, pattern: list = None, repeat: int = -1):
        """
        Trigger vibration pattern asynchronously.
        repeat=-1 means no repeat.
        """
        if pattern is None:
            pattern = self.PATTERN_SHORT

        if self._vibrator is None:
            logger.debug("Haptic buzz skipped (no vibrator)")
            return

        def _vibrate():
            try:
                long_array = [pattern]
                self._vibrator.vibrate(pattern, repeat)
            except Exception as exc:
                logger.warning("Vibration error: %s", exc)

        threading.Thread(target=_vibrate, daemon=True).start()

    def cancel(self):
        if self._vibrator:
            try:
                self._vibrator.cancel()
            except Exception:
                pass
